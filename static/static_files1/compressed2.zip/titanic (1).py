"""
Author      : Yi-Chieh Wu, Sriram Sankararaman
Description : Titanic
"""

# Use only the provided packages!
import math
import csv
from util import *
from collections import Counter

from sklearn.tree import DecisionTreeClassifier
# from sklearn.cross_validation import train_test_split
from sklearn.model_selection import train_test_split
from sklearn.model_selection import cross_val_score

from sklearn import metrics

######################################################################
# classes
######################################################################

class Classifier(object) :
    """
    Classifier interface.
    """
    
    def fit(self, X, y):
        raise NotImplementedError()
        
    def predict(self, X):
        raise NotImplementedError()


class MajorityVoteClassifier(Classifier) :
    
    def __init__(self) :
        """
        A classifier that always predicts the majority class.
        
        Attributes
        --------------------
            prediction_ -- majority class
        """
        self.prediction_ = None
    
    def fit(self, X, y) :
        """
        Build a majority vote classifier from the training set (X, y).
        
        Parameters
        --------------------
            X    -- numpy array of shape (n,d), samples
            y    -- numpy array of shape (n,), target classes
        
        Returns
        --------------------
            self -- an instance of self
        """
        majority_val = Counter(y).most_common(1)[0][0]
        self.prediction_ = majority_val
        return self
    
    def predict(self, X) :
        """
        Predict class values.
        
        Parameters
        --------------------
            X    -- numpy array of shape (n,d), samples
        
        Returns
        --------------------
            y    -- numpy array of shape (n,), predicted classes
        """
        if self.prediction_ is None :
            raise Exception("Classifier not initialized. Perform a fit first.")
        
        n,d = X.shape
        y = [self.prediction_] * n 
        return y


class RandomClassifier(Classifier) :
    
    def __init__(self) :
        """
        A classifier that predicts according to the distribution of the classes.
        
        Attributes
        --------------------
            probabilities_ -- class distribution dict (key = class, val = probability of class)
        """
        self.probabilities_ = None
    
    def fit(self, X, y) :
        """
        Build a random classifier from the training set (X, y).
        
        Parameters
        --------------------
            X    -- numpy array of shape (n,d), samples
            y    -- numpy array of shape (n,), target classes 
        
        Returns
        --------------------
            self -- an instance of self
        """
        
        ### ========== TODO : START ========== ###
        # part b: set self.probabilities_ according to the training set

        # we want to count how many times y equals 1 and divide by the length
        freqDict = Counter(y).most_common(2)
        length = freqDict[0][1] + freqDict[1][1]
        self.probabilities_ = (freqDict[0][1] if freqDict[0][0] == 0 else freqDict[1][1])/length
        
        ### ========== TODO : END ========== ###
        
        return self
    
    def predict(self, X, seed=1234) :
        """
        Predict class values.
        
        Parameters
        --------------------
            X    -- numpy array of shape (n,d), samples
            seed -- integer, random seed
        
        Returns
        --------------------
            y    -- numpy array of shape (n,), predicted classes
        """
        if self.probabilities_ is None :
            raise Exception("Classifier not initialized. Perform a fit first.")
        np.random.seed(seed)
        
        ### ========== TODO : START ========== ###
        # part b: predict the class for each test example
        # hint: use np.random.choice (be careful of the parameters)
        y = np.random.choice(2, X.shape[0], p=[self.probabilities_, 1-self.probabilities_])

            
        ### ========== TODO : END ========== ###        
        return y


######################################################################
# functions
######################################################################
def plot_histograms(X, y, Xnames, yname) :
    n,d = X.shape  # n = number of examples, d =  number of features
    fig = plt.figure(figsize=(20,15))
    nrow = 3; ncol = 3
    for i in range(d) :
        fig.add_subplot (3,3,i)  
        data, bins, align, labels = plot_histogram(X[:,i], y, Xname=Xnames[i], yname=yname, show = False)
        n, bins, patches = plt.hist(data, bins=bins, align=align, alpha=0.5, label=labels)
        plt.xlabel(Xnames[i])
        plt.ylabel('Frequency')
        plt.legend() #plt.legend(loc='upper left')
 
    plt.savefig ('histograms.pdf')


def plot_histogram(X, y, Xname, yname, show = True) :
    """
    Plots histogram of values in X grouped by y.
    
    Parameters
    --------------------
        X     -- numpy array of shape (n,d), feature values
        y     -- numpy array of shape (n,), target classes
        Xname -- string, name of feature
        yname -- string, name of target
    """
    
    # set up data for plotting
    targets = sorted(set(y))
    data = []; labels = []
    for target in targets :
        features = [X[i] for i in range(len(y)) if y[i] == target]
        data.append(features)
        labels.append('%s = %s' % (yname, target))
    
    # set up histogram bins
    features = set(X)
    nfeatures = len(features)
    test_range = list(range(int(math.floor(min(features))), int(math.ceil(max(features)))+1))
    if nfeatures < 10 and sorted(features) == test_range:
        bins = test_range + [test_range[-1] + 1] # add last bin
        align = 'left'
    else :
        bins = 10
        align = 'mid'
    
    # plot
    if show == True:
        plt.figure()
        n, bins, patches = plt.hist(data, bins=bins, align=align, alpha=0.5, label=labels)
        plt.xlabel(Xname)
        plt.ylabel('Frequency')
        plt.legend() #plt.legend(loc='upper left')
        plt.show()

    return data, bins, align, labels


def error(clf, X, y, ntrials=100, test_size=0.2) :
    """
    Computes the classifier error over a random split of the data,
    averaged over ntrials runs.
    
    Parameters
    --------------------
        clf         -- classifier
        X           -- numpy array of shape (n,d), features values
        y           -- numpy array of shape (n,), target classes
        ntrials     -- integer, number of trials
    
    Returns
    --------------------
        train_error -- float, training error
        test_error  -- float, test error
    """
    
    ### ========== TODO : START ========== ###
    # compute cross-validation error over ntrials
    # hint: use train_test_split (be careful of the parameters)
    
    train_error = 0
    test_error = 0
    for i in range(ntrials):
        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=test_size, random_state=i)
        clf.fit(X_train, y_train)
        y_pred_train = clf.predict(X_train)
        y_pred_test = clf.predict(X_test)
        train_err = 1 - metrics.accuracy_score(y_train, y_pred_train, normalize=True)
        test_err = 1 - metrics.accuracy_score(y_test, y_pred_test, normalize=True)
        train_error += train_err
        test_error += test_err
    train_error /= ntrials
    test_error /= ntrials
        
    ### ========== TODO : END ========== ###
    
    return train_error, test_error


def write_predictions(y_pred, filename, yname=None) :
    """Write out predictions to csv file."""
    out = open(filename, 'wb')
    f = csv.writer(out)
    if yname :
        f.writerow([yname])
    f.writerows(list(zip(y_pred)))
    out.close()


######################################################################
# main
######################################################################

def main():
    # load Titanic dataset
    titanic = load_data("titanic_train.csv", header=1, predict_col=0)
    X = titanic.X; Xnames = titanic.Xnames
    y = titanic.y; yname = titanic.yname
    n,d = X.shape  # n = number of examples, d =  number of features
    
    
    
    #========================================
    # part a: plot histograms of each feature
    print('Plotting...')
  #  for i in range(d) :
   #     plot_histogram(X[:,i], y, Xname=Xnames[i], yname=yname)

       
    #========================================
    # train Majority Vote classifier on data
    print('Classifying using Majority Vote...')
    clf = MajorityVoteClassifier() # create MajorityVote classifier, which includes all model parameters
    clf.fit(X, y)                  # fit training data using the classifier
    y_pred = clf.predict(X)        # take the classifier and run it on the training data
    train_error = 1 - metrics.accuracy_score(y, y_pred, normalize=True)
    print('\t-- training error: %.3f' % train_error)
    
    
    
    ### ========== TODO : START ========== ###
    # part b: evaluate training error of Random classifier
    print('Classifying using Random...')
    v = RandomClassifier()
    v.fit(X,y)
    y_pred = v.predict(X)
    train_error = 1 - metrics.accuracy_score(y, y_pred, normalize=True)
    print('\t-- training error for the Random Classifier is: %.3f' % train_error)

    ### ========== TODO : END ========== ###
    
    
    
    ### ========== TODO : START ========== ###
    # part c: evaluate training error of Decision Tree classifier
    # use criterion of "entropy" for Information gain 
    print('Classifying using Decision Tree...')
    
    clf = DecisionTreeClassifier(criterion="entropy")
    clf.fit(X,y)
    y_pred = clf.predict(X)
    train_error = 1 - metrics.accuracy_score(y, y_pred, normalize=True)
    print('\t-- training error for the DecisionTreeClassifier is: %.3f' % train_error)
    ### ========== TODO : END ========== ###
    
    
    
    # note: uncomment out the following lines to output the Decision Tree graph
    """
    # save the classifier -- requires GraphViz and pydot
    import StringIO, pydot
    from sklearn import tree
    dot_data = StringIO.StringIO()
    tree.export_graphviz(clf, out_file=dot_data,
                         feature_names=Xnames)
    graph = pydot.graph_from_dot_data(dot_data.getvalue())
    graph.write_pdf("dtree.pdf") 
    """
    
    
    
    ### ========== TODO : START ========== ###
    # part d: use cross-validation to compute average training and test error of classifiers
    print('Investigating various classifiers...')

    clf = MajorityVoteClassifier()  # create MajorityVote classifier, which includes all model parameters
    train_err, test_err = error(clf, X, y, ntrials=100)
    print ("Majority: train_err: %.3f, test_err: %.3f" % (train_err, test_err))

    clf = RandomClassifier()
    train_err, test_err = error(clf, X, y, ntrials=100)
    print ("Random: train_err: %.3f, test_err: %.3f" % (train_err, test_err))

    clf = DecisionTreeClassifier(criterion="entropy")
    train_err, test_err = error(clf, X, y, ntrials=100)
    print ("DecisionTree: train_err: %.3f, test_err: %.3f" % (train_err, test_err))  
    ### ========== TODO : END ========== ###
    
    
    
    ### ========== TODO : START ========== ###
    # part e: investigate decision tree classifier with various depths
    print('Investigating depths...')
    x=[1,20]
    depth_arr = range(1,21,1)
    train_error_arr = []
    test_error_arr = []
    for depth in range(1,21,1):
        clf = DecisionTreeClassifier(criterion="entropy", max_depth=depth)
        train_err, test_err = error(clf, X, y, ntrials=100)
        train_error_arr.append(train_err)
        test_error_arr.append(test_err)
    plt.plot(depth_arr, train_error_arr, 'green', label="train error")
    plt.plot(depth_arr, test_error_arr, 'purple', label="test error")
    # Place a legend to the right of this smaller subplot.
    #plt.legend(bbox_to_anchor=(1.05, 1), loc=2, borderaxespad=-5.0)
    plt.legend(bbox_to_anchor=(1, 0), loc=2, borderaxespad=-5.0)
    plt.xticks(np.arange(min(x), max(x)+1, 1.0))
    plt.xlabel("Depth of Tree")
    plt.ylabel("Error")
    plt.show()

    ### ========== TODO : END ========== ###
    
    
    
    ### ========== TODO : START ========== ###
    # part f: investigate decision tree classifier with various training set sizes
    '''print('Investigating training set sizes...')
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.1) # was 0.1

    tree_train_err_arr = []
    tree_test_err_arr = []

    increment_arr = [0.05, 0.1, 0.15, 0.2, 0.25, 0.3, 0.35, 0.4, 0.45, 0.5, 0.55, 0.6, 0.65, 0.7, 0.75, 0.8, 0.85, 0.9, 0.95]

    for i in increment_arr:
        train_x, test_x, train_y, test_y = train_test_split(X_train, y_train, test_size=1-i)

        clf_tree = DecisionTreeClassifier(criterion="entropy", max_depth=3)
        train_err, test_err = error(clf_tree, train_x, train_y, ntrials=100)

        tree_train_err_arr.append(train_err)
        tree_test_err_arr.append(test_err)


    plt.plot(increment_arr, tree_train_err_arr, 'purple', label="train error")
    plt.plot(increment_arr, tree_test_err_arr, 'green', label="test error")

    # Place a legend to the right of this smaller subplot.
    plt.legend()
    plt.xlabel("Amount of Training Data")
    plt.ylabel("Error")
    plt.show() '''
    print('Investigating training set sizes...')
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.1)
    increment_arr = [0.05, 0.1, 0.15, 0.2, 0.25, 0.3, 0.35, 0.4, 0.45, 0.5, 0.55, 0.6, 0.65, 0.7, 0.75, 0.8, 0.85, 0.9, 0.95]
    splits = []
    all_errors = {
        'dt_train_errors'  : [],
        'dt_test_errors'   : []
    }
    #for i in range(1, 20):
    for i in increment_arr:
        total_dt_train_error = 0
        total_dt_test_error = 0
        for j in range(1, 101):
            #if i == 10:
                #X_train_subset = X_train
                #y_train_subset = y_train
            #else:
            X_train_subset, X_test_subset, y_train_subset, y_test_subset = train_test_split(X_train, y_train, train_size=i, random_state=j)


            errors = {}
            dtclf = DecisionTreeClassifier(criterion='entropy', max_depth=3) # create DecisionTree classifier, which includes all model parameters
            

            dtclf.fit(X_train_subset, y_train_subset)      # fit training data using the classifier
            

            y_pred_train = dtclf.predict(X_train_subset)        # take the classifier and run it on the training data
            dt_train_error = 1 - metrics.accuracy_score(y_train_subset, y_pred_train, normalize=True)
            y_pred_test = dtclf.predict(X_test)
            dt_test_error = 1 - metrics.accuracy_score(y_test, y_pred_test, normalize=True)
            # print('dt  with %.1f training had %.3f training error and %.3f test error' % (0.1*i, dt_train_error, dt_test_error))



            total_dt_train_error += dt_train_error
            total_dt_test_error += dt_test_error

        splits.append(i)

        all_errors['dt_train_errors'].append(total_dt_train_error / 100)
        all_errors['dt_test_errors'].append(total_dt_test_error / 100)

    # plt.title('KNeighbors Learning Curves')
    # plt.xlabel('portion of training set used')
    # plt.ylabel('error rate')

    # plt.legend(loc='upper right')
    # plt.show()

    # plt.title('Decision Tree Learning Curves')
    plt.xlabel('Amount of Training Data')
    plt.ylabel('Error')
    plt.plot(splits, all_errors['dt_train_errors'], 'green', label='Training Error')
    plt.plot(splits, all_errors['dt_test_errors'], 'purple', label='Test Error')
    x=[0,1]
    plt.xticks(np.arange(min(x), max(x), 0.1))
    plt.legend(loc='lower right')
    plt.show()

  


    ### ========== TODO : END ========== ###
    
       
    print('Done')


if __name__ == "__main__":
    main()
